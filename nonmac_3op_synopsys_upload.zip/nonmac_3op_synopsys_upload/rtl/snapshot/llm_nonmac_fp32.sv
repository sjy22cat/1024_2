`timescale 1ns/1ps
// Distributed non-MAC array: one small FP32 datapath per tile/element.
// One common controller/reduction network and one system-wide Softmax instance.
// Packed buses here are compatibility wiring; each tile receives four FP32 words.
module llm_nonmac_fp32 #(
 parameter LANES=1024,
 // Kept for source compatibility. This distributed implementation always reuses storage.
 parameter REGISTER_CLEANUP=1,
 // Wrapper preloads on its external accept edge, then launches next cycle.
 // Standalone callers keep the original cmd_valid/cmd_ready protocol.
 parameter PRELOAD_INPUTS=0,
 parameter SOFTMAX_LANES=(LANES>=256)?256:(2**($clog2(LANES+1)-1)),
 parameter SOFTMAX_EXP_LANES=(SOFTMAX_LANES>=64)?64:SOFTMAX_LANES
)(
 input wire clk,rst_n,
 input wire cmd_valid, output wire cmd_ready,
 input wire [4:0] cmd_op, input wire [10:0] cmd_len,
 input wire [31:0] cmd_a,cmd_b,cmd_c,cmd_d,cmd_epsilon,cmd_tag,
 input wire cmd_vector,
 input wire [LANES*32-1:0] cmd_x,cmd_y,cmd_gamma,cmd_beta,
 output reg out_valid, input wire out_ready,
 output reg [31:0] out_data,out_aux,out_tag,
 output wire [LANES*32-1:0] out_vector, output reg [10:0] out_len,
 output reg out_error, output wire busy,
 output reg [31:0] cycle_count,read_count,write_count,
 output wire mem_req_valid, input wire mem_req_ready,
 output wire mem_write, output wire [12:0] mem_addr,
 output wire [31:0] mem_wdata,
 input wire mem_rsp_valid, output wire mem_rsp_ready,
 input wire [31:0] mem_rdata,
 input wire cmd_load
);
 localparam IDLE=0,LOAD_REQ=1,LOAD_WAIT=2,EXEC=3,STORE=4,RESPONSE=5,SM_LOAD=6,SM_START=7;
 localparam P_CHECK=0,P_BASIC=1,P_RSQRT=2,P_SIG_EXP=3,P_SIG_ADD=4,
 P_SIG_DIV=5,P_ACT_MUL=6,P_GATE=7,P_GELU_SQ=8,P_GELU_CUBE=9,
 P_GELU_COEFF=10,P_GELU_ADD=11,P_GELU_GAIN=12,P_SM_MAX=13,
 P_SM_SUB=14,P_SM_EXP=15,P_SM_SUM=16,P_INV=17,P_SM_MUL=18,
 P_N_SQ=19,P_N_SUM=20,P_N_DIV=21,P_EPS=22,P_N_SQRT=23,
 P_N_MUL=24,P_GAMMA=25,P_BETA=26,P_MEAN_SUM=27,P_MEAN_DIV=28,
 P_CENTER=29,P_ROPE_A=30,P_ROPE_B=31,P_ROPE_COMB=32,
 P_PAIR_A=33,P_PAIR_B=34,P_PAIR_SUB=35,P_PAIR_C=36,P_PAIR_D=37,
 P_PAIR_ADD=38,P_FINISH=39;
 localparam TREE_LEAVES=2**$clog2(LANES);
 localparam [31:0] ONE=32'h3f800000;
 reg [2:0] state;
 reg [5:0] phase;
 reg [4:0] op_q;
 reg [10:0] length_q,transfer_idx;
 reg [1:0] bank_q;
 reg scratch_q;
 reg loaded_q;
 // Depth one, LANES*32 bits wide. Each lane is wired to its own slice.
 wire [LANES*32-1:0] tile_values,tile_squares;
 reg [31:0] pair_t0,pair_t1;
 reg [31:0] epsilon_q,scale_q,stat_q,mean_q,pair_aux_q;
 wire [LANES*32-1:0] lane_result,final_vector;
 wire [LANES-1:0] lane_error,input_error;
 wire [31:0] sum_tree[1:2*TREE_LEAVES-1];
 wire [2*TREE_LEAVES-1:1] sum_error;
 // Shared barrel shifts avoid a separate 1024-to-1 partner mux in each lane.
 // Pointwise FFN operations never consume cross-lane RoPE operands. Keep
 // those wide broadcasts quiet rather than redistributing every lane update.
 wire [LANES*32-1:0] rope_right=(op_q==24)?(tile_values >> ((length_q>>1)*32)):{LANES*32{1'b0}};
 wire [LANES*32-1:0] rope_left=(op_q==24)?(tile_values << ((length_q>>1)*32)):{LANES*32{1'b0}};
 wire load_rope=cmd_vector && (cmd_op==24 || cmd_op==10);
 wire [LANES*32-1:0] cos_left=load_rope?(cmd_gamma << ((cmd_len>>1)*32)):{LANES*32{1'b0}};
 wire [LANES*32-1:0] sin_left=load_rope?(cmd_beta << ((cmd_len>>1)*32)):{LANES*32{1'b0}};
 function automatic finite(input [31:0] a);
  finite=(a[30:23]!=8'hff);
 endfunction
 function automatic [31:0] int_fp(input [10:0] n);
  integer k,m; reg [31:0] f; reg [7:0] e;
  begin
   m=0;for(k=0;k<11;k=k+1)if(n[k])m=k;
   f={21'b0,n}<<(23-m);e=127+m;
   int_fp=n==0?0:{1'b0,e,f[22:0]};
  end
 endfunction
 function automatic legal_op(input [4:0] op);
  legal_op=(op<=12)||(op>=16&&op<=25);
 endfunction
 function automatic [5:0] first_phase(input [4:0] op);
  begin
   case(op)
    7,8,11,21,23:first_phase=P_SIG_EXP;
    9,22:first_phase=P_GELU_SQ;
    10:first_phase=P_PAIR_A;
    17:first_phase=P_N_SQ;
    18:first_phase=P_MEAN_SUM;
    24:first_phase=P_ROPE_A;
    default:first_phase=P_BASIC;
   endcase
  end
 endfunction
 wire [4:0] load_op=(cmd_vector&&cmd_op==10)?5'd24:cmd_op;
 wire load_need_y=(load_op<=3)||(load_op==11)||(load_op==19)||(load_op==23)||(load_op==10);
 wire load_need_gamma=(load_op==17)||(load_op==18)||(load_op==24)||(load_op==10);
 wire load_need_beta=(load_op==18)||(load_op==24)||(load_op==10);
 wire capture_command=PRELOAD_INPUTS?(cmd_load&&!loaded_q):cmd_valid;
 wire [31:0] length_fp=int_fp(length_q);
 wire need_y=(op_q<=3)||(op_q==11)||(op_q==19)||(op_q==23)||(op_q==10);
 wire need_gamma=(op_q==17)||(op_q==18)||(op_q==24)||(op_q==10);
 wire need_beta=(op_q==18)||(op_q==24)||(op_q==10);
 wire norm=(op_q==17)||(op_q==18);
 wire gelu=(op_q==9)||(op_q==22);
 wire scalar_phase=(phase==P_N_DIV)||(phase==P_EPS)||(phase==P_N_SQRT)||
                   (phase==P_INV)||(phase==P_MEAN_DIV);
 wire arithmetic_phase=phase!=P_CHECK&&phase!=P_FINISH&&phase!=P_SM_MAX&&
                       phase!=P_SM_SUM&&phase!=P_N_SUM&&phase!=P_MEAN_SUM;
 assign cmd_ready=(state==IDLE);
 assign busy=(state!=IDLE);
 assign mem_req_valid=(state==LOAD_REQ)||(state==STORE);
 assign mem_write=(state==STORE);
 assign mem_addr=(state==STORE)?13'd4096+transfer_idx:
                 {1'b0,bank_q,10'b0}+transfer_idx;
 assign mem_wdata=out_vector[transfer_idx*32+:32];
 assign mem_rsp_ready=(state==LOAD_WAIT);
 wire soft_valid,soft_ready,soft_error;
 wire [LANES*32-1:0] soft_vector;
 wire [31:0] soft_data,soft_aux;
 wire soft_wide_capture=state==IDLE&&capture_command&&load_op==16&&cmd_vector;
 wire soft_wide_launch=PRELOAD_INPUTS?(state==IDLE&&loaded_q&&cmd_valid&&op_q==16&&!scratch_q):soft_wide_capture;
 llm_softmax_fp32 #(.VEC_LEN(LANES),.LANES(SOFTMAX_LANES),.EXP_LANES(SOFTMAX_EXP_LANES),
  .PRELOAD_INPUTS(PRELOAD_INPUTS)) u_softmax(
  .clk(clk),.rst_n(rst_n),
  .cmd_load(PRELOAD_INPUTS&&(soft_wide_capture||state==SM_LOAD)),
  .cmd_valid(soft_wide_launch||(PRELOAD_INPUTS?state==SM_START:state==SM_LOAD)),.cmd_ready(soft_ready),
  .cmd_x(state==SM_LOAD?tile_values:cmd_x),.cmd_len(state==SM_LOAD?length_q:cmd_len),
  .cmd_tag(state==SM_LOAD?out_tag:cmd_tag),.out_valid(soft_valid),
  .out_ready(state==RESPONSE&&out_ready),.out_vector(soft_vector),.out_len(),
  .out_data(soft_data),.out_aux(soft_aux),.out_tag(),.out_error(soft_error),.busy(),.cycle_count());
 assign out_vector=out_error?{LANES*32{1'b0}}:(op_q==16?soft_vector:final_vector);
 genvar g;
 generate for(g=0;g<LANES;g=g+1)begin:g_tile
  wire first_half=g<(length_q>>1);
  wire load_first=g<(cmd_len>>1);
  wire [31:0] gx=cmd_vector?cmd_x[g*32+:32]:(g==0?cmd_a:32'b0);
  wire [31:0] gy=cmd_vector?cmd_y[g*32+:32]:(g==0?cmd_b:32'b0);
  wire [31:0] gg=cmd_vector?((load_op==24&&!load_first)?cos_left[g*32+:32]:cmd_gamma[g*32+:32]):(g==0?cmd_c:32'b0);
  wire [31:0] gb=cmd_vector?((load_op==24&&!load_first)?sin_left[g*32+:32]:cmd_beta[g*32+:32]):(g==0?cmd_d:32'b0);
  wire hit=(g==transfer_idx)||(op_q==24&&bank_q>=2&&g==transfer_idx+(length_q>>1));
  llm_nonmac_tile_fp32 #(.TILE_ID(g)) u_tile(
   .clk(clk),.load(state==IDLE&&capture_command&&load_op!=16),.load_op(load_op),
   .load_x(gx),.load_y(gy),.load_gamma(gg),.load_beta(gb),
   .word_load(state==LOAD_WAIT&&mem_rsp_valid&&hit),.word_role(bank_q),.word_data(mem_rdata),
   .active(g<length_q),.run(state==EXEC&&arithmetic_phase&&op_q!=16&&g<length_q&&(!scalar_phase||g==0)),
   .op_q(op_q),.phase(phase),.stat_q(stat_q),.mean_q(mean_q),.scale_q(scale_q),
   .epsilon_q(epsilon_q),.length_fp(length_fp),
   .rope_partner(first_half?rope_right[g*32+:32]:rope_left[g*32+:32]),.rope_first(first_half),
   .pair_t0(pair_t0),.pair_t1(pair_t1),.value(tile_values[g*32+:32]),.square(tile_squares[g*32+:32]),
   .arithmetic_result(lane_result[g*32+:32]),.input_error(input_error[g]),.arithmetic_error(lane_error[g]));
  assign final_vector[g*32+:32]=(g<length_q)?tile_values[g*32+:32]:32'b0;
 end
 for(g=0;g<TREE_LEAVES;g=g+1)begin:g_leaf
  assign sum_error[TREE_LEAVES+g]=0;
  if(g<LANES)begin:g_real
   assign sum_tree[TREE_LEAVES+g]=(g<length_q && (phase==P_MEAN_SUM || phase==P_N_SUM))?
      ((phase==P_MEAN_SUM)?tile_values[g*32+:32]:tile_squares[g*32+:32]):32'b0;
  end else begin:g_pad
   assign sum_tree[TREE_LEAVES+g]=0;
  end
 end
 for(g=1;g<TREE_LEAVES;g=g+1)begin:g_tree
  wire [7:0] status;
  DW_fp_addsub #(23,8,1) u_sum(sum_tree[2*g],sum_tree[2*g+1],3'b000,1'b0,sum_tree[g],status);
  assign sum_error[g]=sum_error[2*g]|sum_error[2*g+1]|!finite(sum_tree[g]);
 end endgenerate
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   state<=IDLE;phase<=P_CHECK;op_q<=0;length_q<=0;transfer_idx<=0;bank_q<=0;scratch_q<=0;
   loaded_q<=0;
   out_valid<=0;out_data<=0;out_aux<=0;out_tag<=0;out_error<=0;out_len<=0;
   cycle_count<=0;read_count<=0;write_count<=0;
   // Wide data registers intentionally have no reset; valid gates consumption.
  end else begin
   if(state!=IDLE&&state!=RESPONSE)cycle_count<=cycle_count+1;
   case(state)
    IDLE:if(capture_command)begin
     op_q<=load_op;
     length_q<=(cmd_vector||cmd_op>=16)?cmd_len:11'd1;
     stat_q<=0;mean_q<=0;pair_aux_q<=0;pair_t0<=0;pair_t1<=0;
     epsilon_q<=cmd_epsilon;scale_q<=cmd_b;out_tag<=cmd_tag;
     out_valid<=0;out_error<=0;cycle_count<=0;read_count<=0;write_count<=0;
     scratch_q<=!cmd_vector&&cmd_op>=16;transfer_idx<=0;bank_q<=0;phase<=P_CHECK;
     state<=(!cmd_vector&&cmd_op>=16)?LOAD_REQ:EXEC;
     if(!legal_op(cmd_op)||((cmd_vector||cmd_op>=16)&&
       (cmd_len==0||cmd_len>LANES||cmd_len>1024))||
       ((cmd_op==24||(cmd_vector&&cmd_op==10))&&cmd_len[0]))begin
      out_error<=1;scratch_q<=0;state<=EXEC;phase<=P_FINISH;
     end
     if(PRELOAD_INPUTS)begin loaded_q<=1;state<=IDLE;end
    end else if(PRELOAD_INPUTS&&loaded_q&&cmd_valid)begin
     // All fields already belong to this command. Never resample host inputs.
     loaded_q<=0;state<=scratch_q?LOAD_REQ:EXEC;
    end
    LOAD_REQ:if(mem_req_ready)begin state<=LOAD_WAIT;read_count<=read_count+1;end
    LOAD_WAIT:if(mem_rsp_valid)begin
     if(transfer_idx+1>=((op_q==24&&bank_q>=2)?(length_q>>1):length_q))begin
      transfer_idx<=0;
      if(bank_q==0&&need_y)begin bank_q<=1;state<=LOAD_REQ;end
      else if(bank_q<2&&need_gamma)begin bank_q<=2;state<=LOAD_REQ;end
      else if(bank_q<3&&need_beta)begin bank_q<=3;state<=LOAD_REQ;end
      else state<=op_q==16?SM_LOAD:EXEC;
     end else begin transfer_idx<=transfer_idx+1;state<=LOAD_REQ;end
    end
    SM_LOAD:state<=PRELOAD_INPUTS?SM_START:EXEC;
    SM_START:state<=EXEC;
    EXEC:if(op_q==16&&phase!=P_FINISH)begin
     if(soft_valid)begin
      out_error<=soft_error;out_len<=length_q;out_data<=soft_data;out_aux<=soft_aux;transfer_idx<=0;
      if(scratch_q&&!soft_error)state<=STORE;else begin state<=RESPONSE;out_valid<=1;end
     end
    end else begin
     if(arithmetic_phase&&(|lane_error))out_error<=1;
     case(phase)
      P_CHECK:begin
       if((|input_error)||(norm&&!finite(epsilon_q))||(op_q==20&&!finite(scale_q)))begin
        out_error<=1;phase<=P_FINISH;
       end else phase<=first_phase(op_q);
      end
      P_BASIC:begin phase<=(op_q==6)?P_RSQRT:P_FINISH;end
      P_RSQRT:begin phase<=P_FINISH;end
      P_SIG_EXP:begin phase<=P_SIG_ADD;end
      P_SIG_ADD:begin phase<=P_SIG_DIV;end
      P_SIG_DIV:begin phase<=(op_q==7)?P_FINISH:P_ACT_MUL;end
      P_ACT_MUL:begin phase<=(op_q==11||op_q==23)?P_GATE:P_FINISH;end
      P_GATE:begin phase<=P_FINISH;end
      P_GELU_SQ:begin phase<=P_GELU_CUBE;end
      P_GELU_CUBE:begin phase<=P_GELU_COEFF;end
      P_GELU_COEFF:begin phase<=P_GELU_ADD;end
      P_GELU_ADD:begin phase<=P_GELU_GAIN;end
      P_GELU_GAIN:begin phase<=P_SIG_EXP;end
      
      
      P_INV:begin stat_q<=lane_result[31:0];phase<=P_N_MUL;end
      P_N_SQ:begin phase<=P_N_SUM;end
      P_N_SUM:begin stat_q<=sum_tree[1];phase<=P_N_DIV;if(sum_error[1])out_error<=1;end
      P_N_DIV:begin stat_q<=lane_result[31:0];phase<=P_EPS;end
      P_EPS:begin stat_q<=lane_result[31:0];phase<=P_N_SQRT;end
      P_N_SQRT:begin stat_q<=lane_result[31:0];phase<=P_INV;end
      P_N_MUL:begin phase<=P_GAMMA;end
      P_GAMMA:begin phase<=op_q==18?P_BETA:P_FINISH;end
      P_BETA:begin phase<=P_FINISH;end
      P_MEAN_SUM:begin stat_q<=sum_tree[1];phase<=P_MEAN_DIV;if(sum_error[1])out_error<=1;end
      P_MEAN_DIV:begin mean_q<=lane_result[31:0];phase<=P_CENTER;end
      P_CENTER:begin phase<=P_N_SQ;end
      P_ROPE_A:begin phase<=P_ROPE_B;end
      P_ROPE_B:begin phase<=P_ROPE_COMB;end
      P_ROPE_COMB:begin phase<=P_FINISH;end
      P_PAIR_A:begin pair_t0<=lane_result[31:0];phase<=P_PAIR_B;end
      P_PAIR_B:begin pair_t1<=lane_result[31:0];phase<=P_PAIR_SUB;end
      P_PAIR_SUB:begin pair_t0<=lane_result[31:0];phase<=P_PAIR_C;end
      P_PAIR_C:begin pair_t1<=lane_result[31:0];phase<=P_PAIR_D;end
      P_PAIR_D:begin phase<=P_PAIR_ADD;end
      P_PAIR_ADD:begin pair_aux_q<=lane_result[31:0];phase<=P_FINISH;end
      P_FINISH:begin
       out_len<=length_q;
       out_data<=(!out_error&&length_q>0&&length_q<=LANES)?tile_values[(length_q-1)*32+:32]:0;
       out_aux<=op_q==10?pair_aux_q:stat_q;
       transfer_idx<=0;
       if(scratch_q&&!out_error)state<=STORE;
       else begin state<=RESPONSE;out_valid<=1;end
      end
      default:begin out_error<=1;phase<=P_FINISH;end
     endcase
    end
    STORE:if(mem_req_ready)begin
     write_count<=write_count+1;
     if(transfer_idx+1>=length_q)begin state<=RESPONSE;out_valid<=1;end
     else transfer_idx<=transfer_idx+1;
    end
    RESPONSE:if(out_ready)begin out_valid<=0;state<=IDLE;end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
