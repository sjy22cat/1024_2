`timescale 1ns/1ps

// Pair one FP32 gate/up chunk and issue SwiGLU through the shared non-MAC
// VECTOR endpoint. Independent ready/valid inputs allow either projection
// to finish first. No word-scratch staging, writes, or reads are generated.
// Connect command/result signals to yrr_1017_top's non-MAC host interface:
// vector=1, from_reduce=0, a/b/c/d/epsilon/gamma/beta=0, all remaining fields
// below. o_vector is an FP32 downstream stream; MXFP4 quantization and the
// down-projection scheduler remain external. One chunk may be outstanding.
module ffn_swiglu_direct_1017 #(parameter integer LANES=1024)(
    input wire clk,rst_n,
    input wire i_gate_valid,output wire o_gate_ready,
    input wire [LANES*32-1:0] i_gate,
    input wire [10:0] i_gate_len,input wire [31:0] i_gate_tag,
    input wire i_up_valid,output wire o_up_ready,
    input wire [LANES*32-1:0] i_up,
    input wire [10:0] i_up_len,input wire [31:0] i_up_tag,
    output wire o_cmd_valid,input wire i_cmd_ready,
    output wire [4:0] o_cmd_op,output wire [10:0] o_cmd_len,
    output wire [31:0] o_cmd_tag,
    output wire [LANES*32-1:0] o_cmd_x,o_cmd_y,
    input wire i_result_valid,output wire o_result_ready,
    input wire [LANES*32-1:0] i_result_vector,
    input wire [10:0] i_result_len,input wire [31:0] i_result_tag,
    input wire i_result_error,
    output wire o_valid,input wire i_ready,
    output wire [LANES*32-1:0] o_vector,
    output wire [10:0] o_len,output wire [31:0] o_tag,
    output wire o_error,output wire o_busy
);
    localparam COLLECT=0,ISSUE=1,WAIT_RESULT=2;
    reg [1:0] state;
    reg gate_present_q,up_present_q;
    reg [LANES*32-1:0] gate_q,up_q;
    reg [10:0] gate_len_q,up_len_q;
    reg [31:0] gate_tag_q,up_tag_q;
    wire bad_pair=gate_len_q==0 || gate_len_q>LANES || gate_len_q>1024 ||
        gate_len_q!=up_len_q || gate_tag_q!=up_tag_q;
    assign o_gate_ready=state==COLLECT && !gate_present_q;
    assign o_up_ready=state==COLLECT && !up_present_q;
    assign o_busy=state!=COLLECT || gate_present_q || up_present_q;
    assign o_cmd_valid=state==ISSUE;
    // Invalid pairs use the existing core error response, preserving one
    // result/command and the gate tag without a second response arbiter.
    assign o_cmd_op=bad_pair?5'd31:5'd23;
    assign o_cmd_len=gate_len_q;assign o_cmd_tag=gate_tag_q;
    assign o_cmd_x=gate_q;assign o_cmd_y=up_q;
    assign o_valid=state==WAIT_RESULT && i_result_valid;
    assign o_result_ready=state==WAIT_RESULT && i_ready;
    assign o_vector=i_result_vector;assign o_len=i_result_len;
    assign o_tag=i_result_tag;assign o_error=i_result_error;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=COLLECT;gate_present_q<=0;up_present_q<=0;end
        else case(state)
            COLLECT:begin
                if(i_gate_valid && o_gate_ready) begin
                    gate_q<=i_gate;gate_len_q<=i_gate_len;gate_tag_q<=i_gate_tag;gate_present_q<=1;
                end
                if(i_up_valid && o_up_ready) begin
                    up_q<=i_up;up_len_q<=i_up_len;up_tag_q<=i_up_tag;up_present_q<=1;
                end
                if((gate_present_q || (i_gate_valid && o_gate_ready)) &&
                   (up_present_q || (i_up_valid && o_up_ready))) state<=ISSUE;
            end
            ISSUE:if(i_cmd_ready) state<=WAIT_RESULT;
            WAIT_RESULT:if(i_result_valid && i_ready) begin
                gate_present_q<=0;up_present_q<=0;state<=COLLECT;
            end
            default:begin state<=COLLECT;gate_present_q<=0;up_present_q<=0;end
        endcase
    end
endmodule
