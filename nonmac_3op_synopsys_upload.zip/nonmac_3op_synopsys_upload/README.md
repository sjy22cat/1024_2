# RMSNorm / RoPE / SwiGLU：SMIC 28nm 测量包

这三个模块的可靠延迟、面积、能耗应来自**实际 RTL + 官方 DW + SMIC 标准单元库**。软件估算仅用于测量前的吞吐预算。
本包复用 SIM-1023 已有的 RTL，新增直接向量测量包装；原系统 RTL 未改动。快照来源与 SHA256 见 `SOURCE_SNAPSHOT.json`。

## 需要测什么

| 物理引擎 | 顶层参数 | 运行长度 | 输入到输出的范围 |
|---|---|---|---|
| RMSNorm | `nonmac_vector_eval OP=17 LANES=1024` | 128、1024 | 完整 RMSNorm，含平方、求和、均值、epsilon、sqrt/倒数、gamma 缩放 |
| RoPE | `OP=24 LANES=128` | 128 | split-half 旋转，cos/sin 作为已给定输入 |
| SwiGLU | `OP=23 LANES=1024` | 1024 | gate/up 配对适配器、preload、SiLU 与门乘；两个输入同时到达 |

RMSNorm 的两个长度必须使用同一个1024-lane网表，面积只计一次。head norm 是运行长度128，不能另综合小硬件后将其数据套到同一1024-lane引擎上。
SwiGLU 的3072维FFN由三次1024元素命令组成。所有算术都归为这些非MAC功能；不因内部使用 FP 乘加就再做 Attention 的 QK/PV MAC 扣除。

返回 latency **ns**、标准单元面积 **µm²**、动态/漏电/总命令能量 **pJ**。另测 idle dynamic **W**，供模拟器计入命令之间的活动。三种引擎各一个、串行调度，面积不按 head/layer/调用次数重复相加。
范围含引擎/包装/局部寄存器，不含外部GSRAM、PHY、MXFP4转换或sin/cos表生成。这些边界不能与模拟器的搬运成本重复计费。

## 上传及执行

本地构建：`python Attention_confusion/nonmac_ppa/synopsys/build_upload.py`。
上传 **`upload/nonmac_3op_synopsys_upload.zip`** 即可；解压后进入同名目录，将 [完整提示词](synopsys/PROMPT_SYNOPSYS.md) 交给服务器Codex。
它与原 Attention 上传包是两个独立任务，可分别综合。服务器本地提供 SMIC28nm `.db`、官方 DW 模型与许可证；包内不含这些授权文件，也不含测试替代DW实现。

```bash
python3 verify_upload.py
cp synopsys/site.example.json synopsys/site.json
# 填写实际SMIC/DW路径，并核对工具时间、电容、功率、面积和read_vcd窗口单位
python3 synopsys/run_flow.py --stage sim
python3 synopsys/run_flow.py --stage dc
python3 synopsys/run_flow.py --stage sta
python3 synopsys/run_flow.py --stage power
python3 synopsys/collect_candidate.py results/smic28
```

库角：SCC28NHKCP_HSC35P140_RVT_V0p2 / RVT / SS /0.9V/125°C。初始1ns，其他约束见 `constraints.tcl`。
脚本尚未在本机的新思环境执行；服务器应按本版工具 `help/man` 修正选项并保存diff。功能周期不等于已闭合的物理ns：预期RMSNorm10、RoPE5、SwiGLU9拍，必须实测；1ns失败时只能列 nominal，valid latency/energy保留缺失。
命令动态能量 = 动态功率W × 命令窗口ns ×1000，漏电另算；另有32拍的稳定空闲窗口。功耗输出按三个种子的mean/min/max报告。无CTS/SPEF、RTL零延迟活动无毛刺等限制须披露。

## 如何返回给模拟器

以 `synopsys/decoder_nonmac.template.json` 填写 `decoder_nonmac.reviewed.json`，附原始报告、工具/库单位、STA/电气/活动覆盖、网表hash和窗口日志。
`collect_candidate.py` 只收集RAW候选，不会自动将其升级为measured。

本地导入：

```powershell
python simulator/SIM-1023/analysis/import_decoder_nonmac_ppa.py <decoder_nonmac.reviewed.json>
```

导入器验证四个profile的时序/功能/活动证据和三个引擎的面积、漏电、空闲动态功耗；缺项会拒绝导入。已有MAC/PE/PHY历史校准不会被新数据覆盖。

## 本地验证与当前边界

仓库中运行 `python Attention_confusion/nonmac_ppa/run_local.py`；可加 `--full` 检查默认宽度。它显式使用测试替代DW，仅是数值/控制验证，不是物理PPA。
当前SIM-1023已计入三类计算和必要的GSRAM/系数读取；物理表征前沿用标注的估算周期。面积/能量缺项仍是null，不以零或软件时间替代。
