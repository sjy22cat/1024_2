`timescale 1ns/1ps
module tb_nonmac_vector_eval #(parameter integer OP=17,LANES=1024);
    import nonmac_test_math::*;
    real period_ns=1.0,start_ns;
    integer n=LANES,seed=20261023,seed_arg;
    reg [31:0] rng;
    string vcd;
    initial begin
        if($value$plusargs("CLOCK_NS=%f",period_ns)) begin end
        if($value$plusargs("N=%d",n)) begin end
        if($value$plusargs("SEED=%d",seed)) begin end
        if(period_ns<=0 || n<1 || n>LANES || (OP==24 && n%2)) $fatal(1,"invalid run");
        if($value$plusargs("DUMP_VCD=%s",vcd)) begin $dumpfile(vcd);$dumpvars(0,dut);end
    end
    reg clk=0;always #(period_ns/2) clk=~clk;
    reg rst_n=0,valid=0,ready=0;
    reg [10:0] len=0;
    reg [31:0] tag=0,eps=32'h358637bd;
    reg [LANES*32-1:0] x=0,y=0,gamma=0,beta=0;
    wire cmd_ready,out_valid,error;
    wire [LANES*32-1:0] result;
    wire [10:0] out_len;wire [31:0] out_tag,reads,writes;
    nonmac_vector_eval #(.OP(OP),.LANES(LANES)) dut(
        .clk(clk),.rst_n(rst_n),.i_valid(valid),.o_ready(cmd_ready),.i_len(len),.i_tag(tag),.i_epsilon(eps),
        .i_x(x),.i_y(y),.i_gamma(gamma),.i_beta(beta),.o_valid(out_valid),.i_ready(ready),
        .o_vector(result),.o_len(out_len),.o_tag(out_tag),.o_error(error),
        .o_scratch_reads(reads),.o_scratch_writes(writes));
    function automatic real sample;
        begin rng=rng*1664525+1013904223;sample=(rng[31:20]-2048.0)/1024.0;end
    endfunction
    real xr[0:LANES-1],yr[0:LANES-1],gr[0:LANES-1],br[0:LANES-1];
    integer i,j,cycles,expected_cycles;
    real sum,expected,got,err,maxerr;
    reg [LANES*32-1:0] held;
    reg active=0;
    always @(posedge clk) if(valid && cmd_ready) begin start_ns=$realtime;active=1;end
    always @(posedge out_valid) if(active) begin
        cycles=$rtoi(($realtime-start_ns)/period_ns+0.5);
        $display("WINDOW op=%0d lanes=%0d n=%0d seed=%0d start_ns=%0.6f end_ns=%0.6f cycles=%0d",OP,LANES,n,seed,start_ns,$realtime,cycles);
        active=0;
    end
    initial begin
        repeat(3) @(negedge clk);rst_n=1;
        rng=seed;len=n;tag=seed;
        sum=0;
        for(i=0;i<n;i=i+1) begin
            xr[i]=fp_real(real_fp(sample()));yr[i]=fp_real(real_fp(sample()));
            gr[i]=fp_real(real_fp(1.0+sample()/8.0));br[i]=0;
            x[i*32+:32]=real_fp(xr[i]);y[i*32+:32]=real_fp(yr[i]);
            sum=sum+xr[i]*xr[i];
        end
        if(OP==24) for(i=0;i<n/2;i=i+1) begin
            gr[i]=fp_real(real_fp($cos(i*0.03125+seed%31)));
            br[i]=fp_real(real_fp($sin(i*0.03125+seed%31)));
        end
        for(i=0;i<n;i=i+1) begin gamma[i*32+:32]=real_fp(gr[i]);beta[i*32+:32]=real_fp(br[i]);end
        valid=1;@(negedge clk);valid=0;
        // Inputs/coefficients remain stable until valid for the adapter case;
        // scope includes pairing/preload, but excludes operand delivery time.
        while(!out_valid) @(negedge clk);
        if(error || out_len!=n || out_tag!=tag || reads || writes) $fatal(1,"status/scratch failure");
        expected_cycles=OP==17?10:OP==24?5:9;
        if(cycles!=expected_cycles) $fatal(1,"cycle baseline got=%0d expected=%0d",cycles,expected_cycles);
        maxerr=0;
        for(i=0;i<n;i=i+1) begin
            if(OP==17) expected=xr[i]/$sqrt(sum/n+fp_real(eps))*gr[i];
            else if(OP==23) expected=xr[i]/(1+$exp(-xr[i]))*yr[i];
            else begin
                j=i%(n/2);
                expected=xr[i]*gr[j]+(i<n/2?-xr[i+n/2]:xr[i-n/2])*br[j];
            end
            got=fp_real(result[i*32+:32]);err=$abs(got-expected);
            if((^result[i*32+:32])===1'bx || result[i*32+23+:8]==255 || err>1e-4+1e-3*$abs(expected))
                $fatal(1,"numeric lane=%0d got=%g expected=%g",i,got,expected);
            if(err>maxerr) maxerr=err;
        end
        held=result;
        repeat(3) begin @(negedge clk);if(!out_valid || result!==held || cmd_ready) $fatal(1,"backpressure");end
        $display("PASS NONMAC op=%0d lanes=%0d n=%0d cycles=%0d max_abs_error=%g scratch=0",OP,LANES,n,cycles,maxerr);
        ready=1;@(negedge clk);
        // Separate idle window: clock continues, no reset or output backpressure.
        // Idle dynamic is not assumed zero just because no command is active.
        x=0;y=0;gamma=0;beta=0;repeat(2) @(negedge clk);
        $display("IDLE_BEGIN ns=%0.6f",$realtime);
        repeat(32) @(negedge clk);
        $display("IDLE_END ns=%0.6f",$realtime);
        $finish;
    end
    initial begin repeat(3000) @(negedge clk);$fatal(1,"timeout");end
endmodule
