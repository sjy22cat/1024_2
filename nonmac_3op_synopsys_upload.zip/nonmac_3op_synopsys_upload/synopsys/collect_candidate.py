"""Collect RAW candidate readings; does not mark simulator parameters measured."""
import argparse,csv,json,math,statistics
from pathlib import Path
from flow_helpers import sha

def read(path,site,ns):
    if not path.exists(): return None
    with path.open(encoding="utf-8") as f: data={r["attribute"]:r["value_in_tool_units"] for r in csv.DictReader(f,delimiter="\t")}
    values={}
    for k,v in data.items():
        try: values[k]=float(v)
        except ValueError: return None
    power=site["tool_power_unit_w"]
    dyn=(values["internal_power"]+values["switching_power"])*power
    leak=values["leakage_power"]*power
    return dict(candidate_area_um2=values["area"]*site["library_area_unit_um2"],
                internal_w=values["internal_power"]*power,switching_w=values["switching_power"]*power,
                dynamic_w=dyn,leakage_w=leak,window_ns=ns,
                dynamic_pj=dyn*ns*1000,leakage_pj=leak*ns*1000,total_pj=(dyn+leak)*ns*1000)

def main():
    ap=argparse.ArgumentParser(__doc__);ap.add_argument("results",type=Path);args=ap.parse_args()
    report={"status":"RAW_UNAUDITED_NOT_FOR_SIMULATOR_IMPORT","operations":{}}
    for op in ("rmsnorm","rope","swiglu"):
        root=args.results/op
        manifest=json.loads((root/"manifest.json").read_text(encoding="utf-8"));site=manifest["site"]
        records=[]
        for w in json.loads((root/"windows.json").read_text(encoding="utf-8")):
            duration=w["window_end_ns"]-w["window_start_ns"]
            idle=w["idle_end_ns"]-w["idle_start_ns"]
            records.append(dict(n=w["n"],seed=w["seed"],cycles=w["cycles"],latency_ns=duration,
                command=read(root/(w["tag"]+"_command_raw.tsv"),site,duration),
                idle=read(root/(w["tag"]+"_idle_raw.tsv"),site,idle)))
        report["operations"][op]=dict(hardware_lanes=manifest["lanes"],netlist_sha256=sha(root/"mapped.v"),
                                      records=records,reports=[p.name for p in root.glob("*.rpt")])
    out=args.results/"nonmac_ppa.raw_candidate.json"
    out.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    print(out)
    print("Audit units, complete mapping, STA and activity; fill decoder_nonmac.reviewed.json from template.")

if __name__=="__main__":main()
