source synopsys/common.tcl
set_app_var target_library $target_db
set_app_var synthetic_library [list dw_foundation.sldb]
set_app_var link_library [concat [list *] $target_db $extra_link_db [list dw_foundation.sldb]]
define_design_lib WORK -path [file join $run_dir work]
set fd [open sources.f r]
set rtl [split [string trim [read $fd]] \n]
close $fd
analyze -format sverilog $rtl
elaborate nonmac_vector_eval -parameters "OP=$op,LANES=$lanes"
current_design nonmac_vector_eval
link
uniquify
save_report dc_units.rpt {report_units}
source synopsys/constraints.tcl
save_report dc_check_before.rpt {check_design}
# Measure the actual mapped fixed-function specialization, including remaining
# shared controller/local storage. No retiming that changes command protocols.
compile_ultra -no_autoungroup
save_report dc_check_after.rpt {check_design}
save_report dc_area.rpt {report_area -hierarchy}
save_report dc_resources.rpt {report_resources -hierarchy}
save_report dc_constraints.rpt {report_constraint -all_violators}
write -format verilog -hierarchy -output [file join $run_dir mapped.v]
write -format ddc -hierarchy -output [file join $run_dir mapped.ddc]
write_sdc [file join $run_dir mapped.sdc]
exit
