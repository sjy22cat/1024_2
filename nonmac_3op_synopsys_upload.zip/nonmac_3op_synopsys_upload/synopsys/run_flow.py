#!/usr/bin/env python3
"""Measure four runtime profiles on three fixed-function physical engines."""
import argparse,hashlib,json,os,re
from pathlib import Path
from flow_helpers import execute,write_config,sha

ROOT=Path(__file__).resolve().parents[1]
CASES={"rmsnorm":(17,1024,[128,1024]),"rope":(24,128,[128]),"swiglu":(23,1024,[1024])}

def parse(log):
    text=log.read_text(encoding="utf-8",errors="replace")
    m=re.findall(r"WINDOW op=(\d+) lanes=(\d+) n=(\d+) seed=(\d+) start_ns=([\d.]+) end_ns=([\d.]+) cycles=(\d+)",text)
    idle0=re.findall(r"IDLE_BEGIN ns=([\d.]+)",text);idle1=re.findall(r"IDLE_END ns=([\d.]+)",text)
    if len(m)!=1 or "PASS NONMAC" not in text or len(idle0)!=1 or len(idle1)!=1:
        raise ValueError("Missing functional/power window evidence: "+str(log))
    op,lanes,n,seed,start,end,cycles=m[0]
    return dict(op=int(op),lanes=int(lanes),n=int(n),seed=int(seed),window_start_ns=float(start),
                window_end_ns=float(end),cycles=int(cycles),idle_start_ns=float(idle0[0]),idle_end_ns=float(idle1[0]))

def main():
    ap=argparse.ArgumentParser(__doc__)
    ap.add_argument("--site",default="synopsys/site.json")
    ap.add_argument("--stage",required=True,choices=("sim","dc","sta","power","all"))
    ap.add_argument("--operation",default="all",choices=("all",)+tuple(CASES))
    ap.add_argument("--seeds",default="20261023,20261024,20261025")
    ap.add_argument("--output",default="results/smic28")
    args=ap.parse_args();os.chdir(ROOT)
    site=json.loads(Path(args.site).read_text(encoding="utf-8"))
    for p in site["target_db"]+site["extra_link_db"]:
        if not Path(p).is_file(): raise FileNotFoundError(p)
    if not Path(site["dw_sim_dir"]).is_dir(): raise FileNotFoundError(site["dw_sim_dir"])
    sources=(ROOT/"sources.f").read_text(encoding="utf-8").splitlines()
    for name in (CASES if args.operation=="all" else [args.operation]):
        op,lanes,lengths=CASES[name]
        out=Path(args.output).resolve()/name;out.mkdir(parents=True,exist_ok=True)
        config=dict(site,op=op,lanes=lanes)
        identity=dict(operation=name,op=op,lanes=lanes,site=site,source_sha256={n:sha(ROOT/n) for n in sources})
        manifest=out/"manifest.json"
        if manifest.exists() and json.loads(manifest.read_text(encoding="utf-8"))!=identity:
            raise ValueError("Changed RTL/config: choose another --output")
        manifest.write_text(json.dumps(identity,indent=2)+"\n",encoding="utf-8")
        cfg=write_config(config,out);env=dict(os.environ,NONMAC_CONFIG_TCL=str(cfg))
        for stage in (["sim","dc","sta","power"] if args.stage=="all" else [args.stage]):
            if stage=="sim":
                binary=out/"simv";top="tb_nonmac_vector_eval"
                sf=out/"simulation.f"
                sf.write_text("tb/nonmac_tb_math.sv\n"+"\n".join(sources)+"\ntb/tb_nonmac_vector_eval.sv\n",encoding="utf-8")
                execute(["vcs","-full64","-sverilog","-timescale=1ns/1ps","-debug_access+all",
                         "-top",top,f"-pvalue+{top}.OP={op}",f"-pvalue+{top}.LANES={lanes}",
                         "-f",str(sf),"-y",site["dw_sim_dir"],"+libext+.v+.sv","-o",str(binary)],out/"compile.log",env)
                windows=[]
                for n in lengths:
                    for seed in map(int,args.seeds.split(",")):
                        tag=f"n{n}_seed{seed}";vcd=out/(tag+".vcd");log=out/(tag+".log")
                        execute([str(binary),f"+N={n}",f"+SEED={seed}",f"+CLOCK_NS={site['period_ns']}",f"+DUMP_VCD={vcd}"],log,env)
                        w=parse(log)
                        if abs(w["window_end_ns"]-w["window_start_ns"]-w["cycles"]*site["period_ns"])>1e-5:
                            raise ValueError("cycle/window mismatch")
                        windows.append(dict(w,tag=tag,activity_vcd=str(vcd),activity_sha256=sha(vcd)))
                (out/"windows.json").write_text(json.dumps(windows,indent=2)+"\n",encoding="utf-8")
            elif stage=="dc":
                execute(["dc_shell","-f","synopsys/dc.tcl"],out/"dc.log",env)
                if not (out/"mapped.v").is_file(): raise RuntimeError("Incomplete mapping")
            elif stage=="sta":
                env["NONMAC_STAGE"]="sta";write_config(config,out)
                execute(["pt_shell","-f","synopsys/pt.tcl"],out/"sta.log",env)
            else:
                if not isinstance(site.get("read_vcd_time_unit_ns"),(int,float)) or site["read_vcd_time_unit_ns"]<=0:
                    raise ValueError("Confirm read_vcd time units in site.json before power")
                env["NONMAC_STAGE"]="power"
                for w in json.loads((out/"windows.json").read_text(encoding="utf-8")):
                    if sha(Path(w["activity_vcd"]))!=w["activity_sha256"]: raise ValueError("Changed activity")
                    for mode,start,end in (("command",w["window_start_ns"],w["window_end_ns"]),
                                           ("idle",w["idle_start_ns"],w["idle_end_ns"])):
                        tag=w["tag"]+"_"+mode
                        write_config(config,out,dict(window_start_ns=start,window_end_ns=end,
                                     activity_vcd=w["activity_vcd"],power_tag=tag))
                        execute(["pt_shell","-f","synopsys/pt.tcl"],out/(tag+".log"),env)
        print(name,"reports:",out)
    print("Audit units/STA/activity before filling decoder_nonmac.reviewed.json; missing data stay null.")

if __name__=="__main__":main()
