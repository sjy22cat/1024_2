from datetime import datetime
from pathlib import Path
import hashlib,json,shutil,tempfile,zipfile
ROOT=Path(__file__).resolve().parents[1]
NAME="nonmac_3op_synopsys_upload"
VERIFY='''from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
m=json.loads((r/"UPLOAD_MANIFEST.json").read_text(encoding="utf-8"))
bad=[n for n,h in m["files"].items() if not (r/n).is_file() or hashlib.sha256((r/n).read_bytes()).hexdigest()!=h]
if bad: raise SystemExit(str(bad))
assert not any("nonmac_test_dw" in n for n in m["files"])
print("PASS upload SHA256:",len(m["files"]),"files; no test DW models or licensed libraries")
'''
def main():
    output=ROOT/"upload";output.mkdir(exist_ok=True)
    names=["README.md","SOURCE_SNAPSHOT.json","sources.f","tb/nonmac_tb_math.sv","tb/tb_nonmac_vector_eval.sv"]
    names+=(ROOT/"sources.f").read_text(encoding="utf-8").splitlines()
    names += ["synopsys/"+n for n in ("site.example.json","common.tcl","constraints.tcl","dc.tcl","pt.tcl",
        "flow_helpers.py","run_flow.py","collect_candidate.py","PROMPT_SYNOPSYS.md","decoder_nonmac.template.json","build_upload.py")]
    for n in ("local_validation.json","local_validation_small.json","local_validation_full.json","local_validation_status.json"):
        if (ROOT/n).is_file(): names.append(n)
    with tempfile.TemporaryDirectory(prefix="nonmac3-bundle-") as td:
        folder=Path(td)/NAME;folder.mkdir()
        for n in names:
            target=folder/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/n,target)
        (folder/"verify_upload.py").write_text(VERIFY,encoding="utf-8")
        names += ["verify_upload.py","UPLOAD_FILE_LIST.txt"]
        (folder/"UPLOAD_FILE_LIST.txt").write_text("\n".join(sorted(names+["UPLOAD_MANIFEST.json"]))+"\n",encoding="utf-8")
        hashes={n:hashlib.sha256((folder/n).read_bytes()).hexdigest() for n in names}
        (folder/"UPLOAD_MANIFEST.json").write_text(json.dumps(dict(files=hashes),indent=2)+"\n",encoding="utf-8")
        zpath=Path(td)/(NAME+".zip")
        with zipfile.ZipFile(zpath,"w",zipfile.ZIP_DEFLATED) as z:
            for n in sorted(names+["UPLOAD_MANIFEST.json"]): z.write(folder/n,NAME+"/"+n)
        with zipfile.ZipFile(zpath) as z:
            assert z.testzip() is None
            for n,h in hashes.items(): assert hashlib.sha256(z.read(NAME+"/"+n)).hexdigest()==h
        previous=[output/NAME,output/(NAME+".zip")]
        if any(p.exists() for p in previous):
            history=ROOT.parent/"_history"/("nonmac3_upload_"+datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
            history.mkdir(parents=True)
            for p in previous:
                assert p.resolve().parent==output.resolve()
                if p.exists(): shutil.move(str(p),str(history/p.name))
        shutil.copytree(folder,output/NAME);shutil.copyfile(zpath,output/(NAME+".zip"))
    print(output/(NAME+".zip"));print("PASS ZIP/expanded SHA256",len(hashes),"files")
if __name__=="__main__":main()
