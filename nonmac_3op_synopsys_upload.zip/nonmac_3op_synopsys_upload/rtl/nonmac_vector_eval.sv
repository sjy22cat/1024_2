`timescale 1ns/1ps
// Characterize the existing distributed non-MAC core with one fixed function.
// OP=17 RMSNorm (LANES=1024, runtime length 128/1024), OP=24 RoPE (128),
// OP=23 SwiGLU (1024), including the real gate/up adapter and preload cycle.
// FP32 vector inputs/outputs; conversion, GSRAM/PHY and cos/sin generation external.
module nonmac_vector_eval #(parameter integer OP=17, LANES=1024)(
    input wire clk,rst_n,i_valid,
    output wire o_ready,
    input wire [10:0] i_len,
    input wire [31:0] i_tag,i_epsilon,
    input wire [LANES*32-1:0] i_x,i_y,i_gamma,i_beta,
    output wire o_valid,input wire i_ready,
    output wire [LANES*32-1:0] o_vector,
    output wire [10:0] o_len,output wire [31:0] o_tag,
    output wire o_error,output wire [31:0] o_scratch_reads,o_scratch_writes
);
    wire cv,cr,cload,ov,ordy;
    wire [4:0] cop;
    wire [10:0] clen,olen;
    wire [31:0] ctag,otag;
    wire [LANES*32-1:0] cx,cy,result;
    wire err;
    generate if(OP==23) begin:g_swiglu
        wire br_ready,gv_ready,uv_ready;
        wire cmd_from_bridge;
        reg preloaded_q;
        // Matches the actual wrapper preload-before-launch protocol.
        assign cload=cmd_from_bridge && cr && !preloaded_q;
        assign cv=cmd_from_bridge && preloaded_q;
        assign br_ready=cr && preloaded_q;
        always @(posedge clk or negedge rst_n)
            if(!rst_n) preloaded_q<=0;
            else if(cload) preloaded_q<=1;
            else if(cv && cr) preloaded_q<=0;
        assign o_ready=gv_ready && uv_ready;
        ffn_swiglu_direct_1017 #(.LANES(LANES)) u_pair(
            .clk(clk),.rst_n(rst_n),
            .i_gate_valid(i_valid && uv_ready),.o_gate_ready(gv_ready),.i_gate(i_x),.i_gate_len(i_len),.i_gate_tag(i_tag),
            .i_up_valid(i_valid && gv_ready),.o_up_ready(uv_ready),.i_up(i_y),.i_up_len(i_len),.i_up_tag(i_tag),
            .o_cmd_valid(cmd_from_bridge),.i_cmd_ready(br_ready),.o_cmd_op(cop),.o_cmd_len(clen),.o_cmd_tag(ctag),
            .o_cmd_x(cx),.o_cmd_y(cy),.i_result_valid(ov),.o_result_ready(ordy),
            .i_result_vector(result),.i_result_len(olen),.i_result_tag(otag),.i_result_error(err),
            .o_valid(o_valid),.i_ready(i_ready),.o_vector(o_vector),.o_len(o_len),.o_tag(o_tag),.o_error(o_error),.o_busy());
    end else begin:g_direct
        assign cv=i_valid;assign o_ready=cr;assign cload=1'b0;
        assign cop=OP;assign clen=i_len;assign ctag=i_tag;assign cx=i_x;assign cy=i_y;
        assign o_valid=ov;assign ordy=i_ready;assign o_vector=result;
        assign o_len=olen;assign o_tag=otag;assign o_error=err;
    end endgenerate
    llm_nonmac_fp32 #(.LANES(LANES),.PRELOAD_INPUTS(OP==23)) u_engine(
        .clk(clk),.rst_n(rst_n),.cmd_valid(cv),.cmd_ready(cr),.cmd_load(cload),
        .cmd_op(cop),.cmd_len(clen),.cmd_tag(ctag),.cmd_epsilon(i_epsilon),
        .cmd_a(32'b0),.cmd_b(32'b0),.cmd_c(32'b0),.cmd_d(32'b0),
        .cmd_vector(1'b1),.cmd_x(cx),.cmd_y(cy),.cmd_gamma(i_gamma),.cmd_beta(i_beta),
        .out_valid(ov),.out_ready(ordy),.out_vector(result),.out_len(olen),.out_tag(otag),.out_error(err),
        .out_data(),.out_aux(),.busy(),.cycle_count(),
        .read_count(o_scratch_reads),.write_count(o_scratch_writes),
        .mem_req_valid(),.mem_req_ready(1'b1),.mem_write(),.mem_addr(),.mem_wdata(),
        .mem_rsp_valid(1'b0),.mem_rsp_ready(),.mem_rdata(32'b0));
    initial if(OP!=17 && OP!=23 && OP!=24) $fatal(1,"unsupported fixed operation");
endmodule
