# Executed from package root. run_flow.py supplies a Tcl list, NOT shell text.
source $::env(NONMAC_CONFIG_TCL)
file mkdir $run_dir
set_app_var search_path [concat $search_path [list .] $db_search_dirs]
proc save_report {filename command} {
    global run_dir
    redirect -file [file join $run_dir $filename] {uplevel 1 $command}
}
proc require_nonempty {collection name} {
    if {[sizeof_collection $collection]==0} {error "Missing collection: $name"}
}
