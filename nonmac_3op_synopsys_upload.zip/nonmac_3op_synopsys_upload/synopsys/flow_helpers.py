import hashlib,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def tcl_word(x):
    s=str(x).replace("\\", "/")
    if any(c in s for c in "{}\n\r"): raise ValueError("Unsupported Tcl path/value: "+s)
    return "{"+s+"}"

def execute(cmd,log,env):
    print("RUN", *cmd, flush=True)
    with log.open("w") as out:
        result=subprocess.run(cmd,cwd=ROOT,env=env,stdout=out,stderr=subprocess.STDOUT)
    if result.returncode: raise RuntimeError(f"Command failed ({result.returncode}); see {log}")
    # Synopsys Tcl errors may otherwise return process status 0.
    data=log.read_text(encoding="utf-8",errors="replace")
    if re.search(r"(?m)^\s*(?:Error:|FATAL:|Fatal:)",data):
        raise RuntimeError(f"Tool reported errors; see {log}")

def write_config(site,out,extra=None):
    values=dict(site)
    values["run_dir"]=out.as_posix()
    values["db_search_dirs"]=sorted({str(Path(x).parent) for x in site["target_db"]+site["extra_link_db"]})
    if extra: values.update(extra)
    lines=[]
    for k,v in values.items():
        if isinstance(v,list): expr="[list "+" ".join(tcl_word(i) for i in v)+"]"
        else: expr=tcl_word(v)
        lines.append("set "+k+" "+expr)
    dest=out/"site_config.tcl"
    dest.write_text("\n".join(lines)+"\n",encoding="utf-8")
    return dest

