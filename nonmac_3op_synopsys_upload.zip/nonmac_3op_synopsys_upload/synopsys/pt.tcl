source synopsys/common.tcl
set_app_var link_path [concat [list *] $target_db $extra_link_db]
if {$::env(NONMAC_STAGE)=="power"} {
    set_app_var power_enable_analysis true
    set_app_var power_analysis_mode averaged
}
read_verilog [file join $run_dir mapped.v]
current_design nonmac_vector_eval
link_design nonmac_vector_eval
source synopsys/constraints.tcl
update_timing
save_report pt_units.rpt {report_units}
save_report pt_check.rpt {check_timing -verbose}
save_report pt_coverage.rpt {report_analysis_coverage}
save_report pt_setup.rpt {report_timing -delay_type max -max_paths 20 -nets -transition_time -capacitance -input_pins}
save_report pt_hold.rpt {report_timing -delay_type min -max_paths 20 -nets -transition_time -capacitance -input_pins}
save_report pt_constraints.rpt {report_constraint -all_violators}
save_report pt_design.rpt {report_design}
if {$::env(NONMAC_STAGE)=="power"} {
    read_vcd -strip_path tb_nonmac_vector_eval/dut -time [list \
        [expr {$window_start_ns/$read_vcd_time_unit_ns}] \
        [expr {$window_end_ns/$read_vcd_time_unit_ns}]] $activity_vcd
    update_power
    save_report ${power_tag}_power.rpt {report_power -verbose}
    save_report ${power_tag}_hierarchy.rpt {report_power -hierarchy -levels 5}
    save_report ${power_tag}_coverage.rpt {report_switching_activity}
    save_report ${power_tag}_checks.rpt {check_power -verbose}
    set f [open [file join $run_dir ${power_tag}_raw.tsv] w]
    puts $f "attribute\tvalue_in_tool_units"
    foreach attr {area internal_power switching_power leakage_power total_power} {
        if {[catch {get_attribute -quiet [current_design] $attr} v] || $v==""} {set v UNAVAILABLE}
        puts $f "$attr\t$v"
    }
    close $f
}
exit
